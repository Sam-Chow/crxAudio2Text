chrome.storage.local.get({mediaAccess: false}, function(items) {
  if (!items.mediaAccess) {
    chrome.tabs.create({ url: "html/options.html" });
  } else {
    const buttonNode = document.getElementsByClassName('audio-icon')[0]
    const textNode = document.getElementsByClassName('text')[0]
    buttonNode.addEventListener('click', () => {
      textNode.innerHTML = '我在听…'
      const newRecognition = new SpeechRecognition()
      newRecognition.onresult = event => {
        textNode.classList.remove('waiting')
        textNode.classList.add('finished')
        textNode.innerHTML = event.results[0][0].transcript
      }
      newRecognition.onerror = err => console.log(err)
      newRecognition.start()
    })
  }
})
